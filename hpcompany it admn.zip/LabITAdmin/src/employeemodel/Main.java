package employeemodel;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Employee newEmployee = new Employee("hari", "mukund");
	        newEmployee.setDepartment("Developer");

	        credencialService.showCredentials(newEmployee);
	    }
	

	}


